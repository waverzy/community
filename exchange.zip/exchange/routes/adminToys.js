var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();
var models = require('../models');

router.get('/', function (req, res) {
    if(!req.session.user || req.session.auth !== 'admin') {
        logger.info('user:[' + req.ip + '] request new toys without auth!');
        return res.redirect('adminLogin');
    }
    logger.info('admin:[' + req.session.user + '] open adminToys.html');
    models.Toy.findAll({
        attributes: ['tid', 'name']
    }).then(function (toys) {
        return res.render('adminToys', {'toys': toys});
    }).catch(function (error) {
        logger.error('admin:[' + req.session.user + '] ' + error.stack);
        return res.render('error');
    })
});

router.post('/get', function(req, res) {
    if(!req.session.user || req.session.auth !== 'admin') {
        logger.info('user:[' + req.ip + '] request toy detail without auth!');
        return res.send({'msg': 'logout'});
    }
    var tid = req.body.id || 0;
    if(tid === 0) {
        return res.send({'msg': '传递参数有误！'});
    }
    logger.info('admin:[' + req.session.user + '] begin to get toy detail...');
    var newToy = {};
    newToy.tid = tid;
    models.Toy.findOne({
        where: {
            tid: tid
        }
    }).then(function (toy) {
        if(toy) {
            newToy.shortName = toy.name;
            newToy.pic = toy.pic;
            newToy.desc = toy.description;
            newToy.price = toy.price;
            newToy.state = toy.state;
            return models.Toydetail.findOne({
                where: {
                    tid: tid
                }
            });
        }
        throw new Error('表中未查询到该玩家信息！');
    }).then(function (detail) {
        if(detail) {
            newToy.description = detail.description;
            newToy.name = detail.name;
            newToy.age = detail.age;
            newToy.battery = detail.battery;
            newToy.tip = detail.tip;
            newToy.info = detail.info;
        }
        return models.Toyimage.findAll({
            where: {
                tid: tid
            }
        });
    }).then(function (images) {
        newToy.slide = [];
        newToy.main = [];
        if(images) {
            images.forEach(function (val) {
                if(val.type === 'slide') {
                    newToy.slide.push(val.url);
                }
                if(val.type === 'main') {
                    newToy.main.push(val.url);
                }
            });
        }
        return res.send({'msg': 'success', 'toy': newToy});
    }).catch(function (error) {
        logger.error('user:[' + req.session.user + '] ' + error.stack);
        return res.send({'msg': error.message});
    })
});

router.post('/edit', function (req, res) {
    if(!req.session.user || req.session.auth !== 'admin') {
        logger.info('user:[' + req.ip + '] ready to edit a toy without auth!');
        return res.send({'msg': 'logout'});
    }
    logger.info('user:[' + req.session.user + '] begin to edit a toy');
    var params = JSON.parse(req.body.params);
    var tid = parseInt(params.tid) || 0,
        shortName = params.shortName || '',
        pic = params.pic || '',
        desc = params.desc || '',
        price = parseInt(params.price) || 0,
        state = params.state==='1',
        name = params.name || '',
        age = params.age || '',
        battery = params.battery || '',
        description = params.description || '',
        info = params.info || '',
        tip = params.tip || '',
        slideImages = params.slideImages || [],
        mainImages = params.mainImages || [];
    if (tid === 0 || shortName === '' || pic === '' || desc === '' || price === 0 || name === '' || battery === '' || description === '' || info === '' || tip === '' || slideImages.length === 0) {
        return res.send({'msg': '传递参数有误，请刷新页面后重试！'});
    }
    return models.sequelize.transaction(function (t) {
        return models.Toy.findOne({
            where: {
                tid: tid
            }
        }).then(function (toy) {
            if(toy) {
                toy.name = shortName;
                toy.pic = pic;
                toy.description = desc;
                toy.price = price;
                toy.state = state;
                return toy.save({
                    transaction: t
                });
            } else {
                throw new Error('Toy表中记录不存在！');
            }
        }).then(function () {
            logger.info('[Toy:' + tid +'] updated');
            return models.Toydetail.findOne({
                where: {
                    tid: tid
                }
            });
        }).then(function (detail) {
            if(detail) {
                detail.description = description;
                detail.name = name;
                detail.age = age;
                detail.battery = battery;
                detail.tip = tip;
                detail.info = info;
                return detail.save({
                    transaction: t
                });
            } else {
                throw new Error('Toydetail表中记录不存在！');
            }
        }).then(function () {
            logger.info('[Toydetail:' + tid +'] updated');
            return models.Toyimage.destroy({
                where: {
                    tid: tid,
                    type: ['slide', 'main']
                },
                transaction: t
            });
        }).then(function () {
            logger.info('[Toyimages] cleared');
            var images = [];
            slideImages.forEach(function (val) {
                var temp = {};
                temp.tid = tid;
                temp.type = 'slide';
                temp.url = val;
                images.push(temp);
            });
            mainImages.forEach(function (val) {
                var temp = {};
                temp.tid = tid;
                temp.type = 'main';
                temp.url = val;
                images.push(temp);
            });
            return models.Toyimage.bulkCreate(images,
                { transaction: t });
        });
    }).then(function () {
        logger.info('[Toyimage:' + tid +'] updated');
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.send({'msg': '错误:' + error.message});
    })
});

router.post('/delete', function (req, res) {
    if(!req.session.user || req.session.auth !== 'admin') {
        logger.info('user:[' + req.ip + '] ready to delete toys without auth!');
        return res.send({'msg': 'logout'});
    }
    logger.info('user:[' + req.session.user + '] begin to delete toys');
    var tids = JSON.parse(req.body.toys) || [];
    if(tids.length === 0) {
        return res.send({'msg': '传递参数有误，请刷新页面后重试！'});
    }
    models.Toy.update(
        {state: false},
        {
            where: {
                tid: tids
            }
    }).then(function () {
        logger.info('toys deleted');
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.send({'msg': '错误:' + error.message});
    })
});

router.post('/add', function (req, res) {
    if(!req.session.user || req.session.auth !== 'admin') {
        logger.info('user:[' + req.ip + '] ready to add a toy without auth!');
        return res.send({'msg': 'logout'});
    }
    logger.info('user:[' + req.session.user + '] begin to add a toy');
    var params = JSON.parse(req.body.params);
    var shortName = params.shortName || '',
        pic = params.pic || '',
        desc = params.desc || '',
        price = parseInt(params.price) || 0,
        state = params.state==='1',
        name = params.name || '',
        age = params.age || '',
        battery = params.battery || '',
        description = params.description || '',
        info = params.info || '',
        tip = params.tip || '',
        slideImages = params.slideImages || [],
        mainImages = params.mainImages || [];
    if (shortName === '' || pic === '' || desc === '' || price === 0 || name === '' || battery === '' || description === '' || info === '' || tip === '' || slideImages.length === 0) {
        return res.send({'msg': '传递参数有误，请刷新页面后重试！'});
    }
    return models.sequelize.transaction(function (t) {
        return models.Toy.build({
            name: shortName,
            pic: pic,
            description: desc,
            price: price,
            state: state
        }).save({
            transaction: t
        }).then(function (toy) {
            logger.info('[Toy:' + toy.tid +'] inserted');
            return models.Toydetail.build({
                tid: toy.tid,
                name: name,
                description: description,
                age: age,
                battery: battery,
                tip: tip,
                info: info
            }).save({
                transaction: t
            });
        }).then(function (detail) {
            logger.info('[Toydetail:' + detail.tid +'] inserted');
            var images = [];
            slideImages.forEach(function (val) {
                var temp = {};
                temp.tid = detail.tid;
                temp.type = 'slide';
                temp.url = val;
                images.push(temp);
            });
            mainImages.forEach(function (val) {
                var temp = {};
                temp.tid = detail.tid;
                temp.type = 'main';
                temp.url = val;
                images.push(temp);
            });
            return models.Toyimage.bulkCreate(images,
                { transaction: t });
        });
    }).then(function () {
        logger.info('[Toyimage] inserted');
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.send({'msg': '错误:' + error.message});
    })
});

module.exports = router;
