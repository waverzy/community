/**
 * Created by waver on 2018/2/6.
 */
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();
var models =  require('../models');
var parseString = require('xml2js').parseString;
var crypto = require('crypto');
var utils = require('../core/utils');
var wxUtils = require('../core/wxUtils');

router.post('/', function (req, res) {
   var xml = '';
   req.setEncoding('utf8');
   req.on('data', function (chunk) {
       xml += chunk;
   });
   req.on('end', function() {
       parseString(xml, {explicitArray : false}, function(err, jsonStr) {
           var msgType = jsonStr.xml.MsgType,
               openid = jsonStr.xml.FromUserName;
           if(msgType === 'event') {
               /*var event = jsonStr.xml.Event;
               switch(event) {
                   case "unsubscribe":
                       models.Wxuser.update(
                           {state: false},
                           {where: {
                               openid: openid,
                               user: req.session.user
                           }}
                       ).then(function () {
                           logger.info('[openid]'+openid + ' unsubscribe!');
                       }).catch(function (err) {
                           logger.error('Unbind wxhouse fail when unsubscribe!' + err.stack);
                       });
                       break;
                   default:
                       console.log(jsonStr.xml);
               }*/
           } else {
               console.log(jsonStr.xml);
           }
       });
   });
});

router.get('/', function (req, res) {
    var signature = req.query.signature || '',
        timestamp = req.query.timestamp || '',
        nonce = req.query.nonce || '',
        echostr = req.query.echostr || '';
    console.log('signature:'+signature);
    console.log('timestamp:'+timestamp);
    console.log('nonce:'+nonce);
    console.log('echostr:'+echostr);
    if(signature==='' || timestamp==='' || nonce==='' || echostr==='') {
        return res.send('Invalid Request!');
    }
    var sortArr = [timestamp, nonce, utils.getToken()].sort();
    var sha1 = crypto.createHash('sha1');
    sha1.update(sortArr[0]+sortArr[1]+sortArr[2]);
    var signstr = sha1.digest('hex');
    console.log('signstr:'+signstr);
    if(signature == signstr) {
        return res.send(echostr);
    } else {
        return res.send('Invalid Request!');
    }

});

router.get('/jsapi', function (req, res) {
    var url = req.query.url || '';
    var nonceStr = Math.random().toString(36).substr(2, 15),
        timestamp = parseInt(new Date().getTime() / 1000) + '';
    wxUtils.getJsTicket(function (err, data) {
        if(err) {
            return res.send(err.message);
        }
        var ret = {
            jsapi_ticket: data,
            noncestr: nonceStr,
            timestamp: timestamp,
            url: url
        };
        var rawStr = wxUtils.raw(ret);
        var sha1 = crypto.createHash('sha1');
        sha1.update(rawStr);
        var signature = sha1.digest('hex');
        return res.send({'msg': 'success', 'nonceStr': nonceStr, 'timestamp': timestamp, 'signature': signature, 'appId': utils.getAppid()});
    });
});

module.exports = router;
