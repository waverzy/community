var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();
var models = require('../models');

router.get('/', function (req, res) {
    logger.info('user:[' + req.ip + '] open index.html');
    res.render('index');
});

module.exports = router;
