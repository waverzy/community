/**
 * Created by waver on 2018/1/22.
 */
var models =  require('../models');
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();

router.get('/', function(req, res, next) {
    logger.info('user:[' + req.ip + '] open forget.html');
    res.render('forget');
});

router.post('/', function (req, res) {
    logger.info('user:[' + req.ip + '] begin to find password');
    var password = req.body.password || '',
        msgcode = req.body.msgcode || '',
        mobile = req.body.mobile || '';
    if(mobile === '' || msgcode === '' || password === '') {
        return res.send({'msg': '提交信息有误，请刷新页面后重试！'});
    }
    if(msgcode !== req.session.msgcode || mobile !== req.session.mobile) {
        return res.send({'msg': '短信验证码错误！'});
    }
    models.User.findOne({
        where: {
            name: mobile
        }
    }).then(function (user) {
        if(user) {
            user.password = password;
            return user.save();
        }
        throw new Error('END');
    }).then(function () {
        logger.info('user:[' + mobile + '] has set new password');
        req.session.msgcode = null;
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        if(error.message === 'END') {
            return res.send({'msg': '该手机号尚未注册，无法找回密码！'});
        }
        logger.error('user:[' + mobile + '] ' + error.stack);
        return res.send({'msg': '错误:' + error.message});
    })
});

module.exports = router;
