var models =  require('../models');
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();

router.get('/', function(req, res, next) {
    logger.info('user:[' + req.ip + '] open box.html');
    if(req.session.user) {
        models.Oldtoy.findAll({
            attributes: ['oid', 'name', 'marketprice', 'price', 'brand', 'category', 'old', 'damage', 'func', 'state', 'comment'],
            where: {
                user: req.session.user,
                state: ['reviewing', 'accepted', 'rejected']
            },
            order: 'createdAt DESC'
        }).then(function (toys) {
            if(toys && toys.length>0) {
                for(var i=0; i<toys.length; i++) {
                    if(toys[i].state === 'reviewing') {
                        toys[i].state = "待审核";
                        toys[i].check = false;
                    }
                    if(toys[i].state === 'accepted') {
                        toys[i].state = "审核通过";
                        toys[i].check = true;
                    }
                    if(toys[i].state === 'rejected') {
                        toys[i].state = "审核未通过";
                        toys[i].check = false;
                    }
                }
                return res.render('box', {'oldToys': toys});
            }
            throw new Error('END');
        }).catch(function (error) {
            if(error.message === 'END') {
                return res.render('box');
            }
            logger.error('user:[' + req.session.user + '] ' + error.stack);
            return res.render('error');
        })
    } else {
        return res.render('box');
    }
});

module.exports = router;
