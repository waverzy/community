var models =  require('../models');
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();

/*mock*/
/*router.get('/', function(req, res) {
    var toys = [];
    var toy1 = {};
    toy1.state = "待审核";
    toy1.check = false;
    toy1.oid = 1;
    toy1.name = 'toy1 name';
    toy1.marketprice = 2000;
    toy1.price = 3000;
    toy1.brand = 'LEGO';
    toy1.category = '运动户外';
    toys.push(toy1);
    var toy2 = {};
    toy2.state = "审核通过";
    toy2.check = true;
    toy2.oid = 1;
    toy2.name = 'toy1 name';
    toy2.marketprice = 2000;
    toy2.price = 3000;
    toy2.brand = 'LEGO';
    toy2.category = '运动户外';
    toys.push(toy2);
    return res.render('box', {'oldToys': toys});
});*/

router.get('/', function(req, res) {
    logger.info('user:[' + req.ip + '] open box.html');
    if(req.session.user) {
        models.Oldtoy.findAll({
            attributes: ['oid', 'name', 'marketprice', 'price', 'brand', 'category', 'old', 'damage', 'func', 'state', 'comment'],
            where: {
                user: req.session.user,
                state: ['reviewing', 'accepted', 'rejected']
            },
            order: 'createdAt DESC'
        }).then(function (toys) {
            if(toys && toys.length>0) {
                for(var i=0; i<toys.length; i++) {
                    if(toys[i].state === 'reviewing') {
                        toys[i].state = "待审核";
                        toys[i].check = false;
                    }
                    if(toys[i].state === 'accepted') {
                        toys[i].state = "审核通过";
                        toys[i].check = true;
                    }
                    if(toys[i].state === 'rejected') {
                        toys[i].state = "审核未通过";
                        toys[i].check = false;
                    }
                }
                return res.render('box', {'oldToys': toys});
            }
            throw new Error('END');
        }).catch(function (error) {
            if(error.message === 'END') {
                return res.render('box');
            }
            logger.error('user:[' + req.session.user + '] ' + error.stack);
            return res.render('error');
        })
    } else {
        return res.render('box');
    }
});

router.post('/removeOld', function(req, res) {
    if(!req.session.user) {
        return res.send({'msg': 'logout'});
    }
    logger.info('user:[' + req.session.user + '] begin to remove an old toy');
    var oid = parseInt(req.body.toyid) || 0;
    if(oid === 0) {
        return res.send({'msg': '传入参数有误，请重新打开页面再试！'});
    }
    models.Oldtoy.findOne({
        where: {
            user: req.session.user,
            oid: oid
        }
    }).then(function (toy) {
        if(toy) {
            if(toy.state === 'reviewing' || toy.state === 'accepted' || toy.state === 'rejected') {
                toy.state = 'removed';
                return toy.save();
            } else {
                throw new Error('状态异常，无法删除！');
            }
        }
        logger.info('user:[' + req.session.user + ']名下未查询到就玩具[' + oid + ']');
        throw new Error('END');
    }).then(function () {
        logger.info('user:[' + req.session.user + '] has removed an old toy [oid]' + oid);
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        if(error.message === 'END') {
            return res.send({'msg': '页面出错，请刷新后重试！'});
        }
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.send({'msg': '错误:' + error.message});
    })
});

module.exports = router;
