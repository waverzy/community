var models =  require('../models');
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();

router.get('/', function(req, res) {
    if(!req.session.user) {
        return res.redirect('login');
    }
    logger.info('user:[' + req.session.user + '] open record.html');
    var records = [];
    models.Order.findAll({
        attributes: ['oid', 'createdAt', 'custname', 'mobile', 'address', 'logitime', 'state'],
        where: {
            user: req.session.user,
            state: ['finished', 'paid', 'unpaid']
        },
        order: 'createdAt DESC'
    }).then(function (orders) {
        var oids = [];
        if(orders && orders.length > 0) {
            for(var i=0; i<orders.length; i++) {
                oids.push(orders[i].oid);
                orders[i].newToys = [];
                orders[i].oldToys = [];
                orders[i].orderTime = '';
                orders[i].status = '';
                records.push(orders[i]);
            }
            return models.Record.findAll({
                attributes: ['oid', 'tid', 'name', 'price', 'pic', 'num', 'type'],
                where: {
                    oid: oids
                },
                order: 'oid DESC'
            });
        }
        throw new Error('END');
    }).then(function (results) {
        if(results && results.length > 0) {
            for(var j=0; j<records.length; j++) {
                var exist = false;
                for(var k=0; k<results.length; k++) {
                    if(results[k].oid === records[j].oid) {
                        exist = true;
                        if(results[k].type === 'new') {
                            records[j].newToys.push(results[k]);
                        } else if(results[k].type === 'old'){
                            records[j].oldToys.push(results[k]);
                        }
                    } else {
                        if(exist) {
                            break;
                        }
                    }
                }
                if(!exist) {
                    throw new Error('未查询到部分订单下的商品信息！');
                }
                records[j].oid = 2018;
                records[j].orderTime = formatDate(new Date(records[j].createdAt));
                switch(records[j].state) {
                    case 'finished':
                        records[j].status = '已完成';
                        break;
                    case 'paid':
                        records[j].status = '待配送';
                        break;
                    case 'unpaid':
                        records[j].status = '待支付';
                        records[j].operate = true;
                        break;
                }
            }
            return res.render('records', {'records': records});
        }
        throw new Error('未查询到订单下的商品信息！');
    }).catch(function (error) {
        if(error.message === 'END') {
            return res.render('records', {'records': null});
        }
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.render('error');
    });
});

router.post('/cancel', function(req, res) {
    if(!req.session.user) {
        return res.send({'msg': 'logout'});
    }
    var oid = parseInt(req.body.id) || 0;
    if(oid === 0) {
        return res.send({'msg': '传入参数有误！'});
    }
    var tids = [];
    models.Order.findOne({
        where: {
            oid: oid,
            user: req.session.user
        }
    }).then(function (order) {
        if(order) {
            if(order.state === 'unpaid') {
                order.state = 'canceled';
                return order.save();
            } else {
                throw new Error('订单处于无法取消状态！')
            }
        }
        throw new Error('订单记录不存在！')
    }).then(function () {
        logger.info('order:[' + oid + '] has became canceled.');
        return models.Record.findAll({
            attributes: ['tid'],
            where: {
                oid: oid,
                type: 'old'
            }
        });
    }).then(function (records) {
        if(records && records.length > 0) {
            for(var i=0; i<records.length; i++) {
                tids.push(records[i].tid);
            }
            return models.Oldtoy.findAll({
                where: {
                    oid: tids
                }
            });
        }
        throw new Error('订单异常，未查询到旧玩具记录');
    }).then(function (toys) {
        if(toys && toys.length > 0) {
            for(var i=0; i<toys.length; i++) {
                if(toys[i].state !== 'using') {
                    throw new Error('旧玩具状态异常，请重新打开页面再试！')
                }
            }
            return models.Oldtoy.update(
                {state: 'accepted'},
                {where: {
                    oid: tids
                }}
            );
        }
        throw new Error('未找到订单下的旧玩具信息，请重新打开页面再试！')
    }).then(function () {
        logger.info('order:[' + oid + '] has updated old toys state.');
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        logger.error('user:[' + req.session.user + '] ' + error.stack);
        return res.send({'msg': error.message});
    })
});

function formatDate(date) {
    var yyyy = date.getFullYear(),
        M = date.getMonth() + 1,
        d = date.getDate(),
        h = date.getHours(),
        m = date.getMinutes(),
        s = date.getSeconds();
    var MM = M<10 ? '0'+M : M,
        dd = d<10 ? '0'+d : d,
        hh = h<10 ? '0'+h : h,
        mm = m<10 ? '0'+m : m,
        ss = s<10 ? '0'+s : s;
    return yyyy + '-' + MM + '-' + dd + ' ' + hh  + ':' + mm + ':' + ss;
}

module.exports = router;
