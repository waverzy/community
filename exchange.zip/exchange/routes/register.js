/**
 * Created by waver on 2018/1/22.
 */
var models =  require('../models');
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();

router.get('/', function(req, res, next) {
    logger.info('user:[' + req.ip + '] open register.html');
    res.render('register');
});

router.post('/', function (req, res) {
    logger.info('user:[' + req.ip + '] begin to register');
    var password = req.body.password || '',
        msgcode = req.body.msgcode || '',
        mobile = req.body.mobile || '';
    if(mobile === '' || msgcode === '' || password === '') {
        return res.send({'msg': '提交信息有误，请刷新页面后重试！'});
    }
    if(msgcode !== req.session.msgcode || mobile !== req.session.mobile) {
        return res.send({'msg': '短信验证码错误！'});
    }
    models.User.findOne({
        where: {
            name: mobile
        }
    }).then(function (user) {
        if(user) {
            return res.send({'msg': '该手机号已被注册，如忘记密码可在登录页点击找回密码！'});
        } else {
            return models.User.build({
                name: mobile,
                password: password}).save();
        }
    }).then(function () {
        logger.info('user:[' + mobile + '] has registered');
        req.session.msgcode = null;
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.send({'msg': '错误:' + error.message});
    })
});

module.exports = router;
