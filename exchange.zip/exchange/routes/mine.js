var express = require('express');
var router = express.Router();

router.get('/', function(req, res) {
    if(req.session.user) {
        return res.render('mine', { user: req.session.user });
    } else {
        res.render('mine');
    }
});

module.exports = router;
