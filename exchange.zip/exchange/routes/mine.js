var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();

router.get('/', function(req, res) {
    if(req.session.user) {
        return res.render('mine', { user: req.session.user });
    } else {
        res.render('mine');
    }
});

router.post('/logout', function (req, res) {
    if(req.session.user) {
        logger.info('user:[' + req.session.user + '] begin to logout');
        req.session.user = null;
    }
    return res.send({'msg': 'success'});
});

module.exports = router;
