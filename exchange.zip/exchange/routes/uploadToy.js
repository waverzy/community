/**
 * Created by waver on 2018/1/12.
 */
var models =  require('../models');
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();
var multer = require('multer');
var FILE_PATH = 'images/';
var storage = multer.diskStorage({
    destination: 'public/' + FILE_PATH,
    filename: function(req, file, cb) {
        var fileFormat = (file.originalname).split(".");
        cb(null, Date.now() + "." + fileFormat[fileFormat.length - 1]);
    }
});

router.get('/', function(req, res, next) {
    if(!req.session.user) {
        return res.redirect('login');
    }
    logger.info('user:[' + req.session.user + '] open uploadToy.html');
    models.Item.findAll({
        attributes: ['id', 'name'],
        where: {
            type: 'brand'
        },
        order: 'name ASC'
    }).then(function (brands) {
        if(brands && brands.length > 0) {
            return res.render('uploadToy', {'brands': brands});
        }
        throw new Error('未查询到品牌列表！')
    }).catch(function (error) {
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.render('error');
    });
});

router.post('/upload', function (req, res) {
    logger.info('user:[' + req.session.user + '] begin to upload photo');
    var upload = multer({
        storage: storage,
        limits: {
            files: 1,
            fileSize: 10*1024*1024
        }
    }).single('file');
    upload(req, res, function(err) {
        if(err) {
            logger.error(err.stack);
            return res.send({'msg': err.message});
        }
        logger.info('user:[' + req.session.user + ']upload[' + req.file.filename + '] finished');
        req.session.filename = req.file.filename;
        return res.send({'msg': 'success'});
    });
});

router.post('/toy', function (req, res) {
    logger.info('user:[' + req.ip + '] begin to submit toy');
    var name = req.body.name || '',
        price = parseInt(req.body.price) || 0,
        brand = req.body.brand || '',
        category = req.body.category || '',
        old = req.body.old || '',
        damage = req.body.damage || '',
        func = req.body.func || '';
    if(name === '' || price <= 0 || brand === '' || category === '' || old === '' || damage === '' || func === '') {
        return res.send({'msg': '提交内容有误，请关闭页面后重新打开！'});
    }
    var assessPrice = assess(price, brand, category, old, damage, func);
    if(assessPrice < 0) {
        return res.send({'msg': '提交内容有误，无法进行评估，请重新打开页面再试！'});
    }
    models.Oldtoy.build({
        user: req.session.user,
        name: name,
        marketprice: req.body.price,
        assessprice: assessPrice,
        price: assessPrice,
        brand: brand,
        category: category,
        old: old,
        damage: damage,
        func: func,
        pic: 'images/' + req.session.filename,
        state: 'reviewing'}).save().then(function () {
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        logger.error('user:[' + req.session.user + '] ' + error.stack);
        return res.send({'msg': error.message});
    })
});

function assess(price, brand, category, old, damage, func) {
    models.Item.findAll({
        attributes: ['id', 'rate'],
        where: {
            id: [brand, category, old, damage, func]
        },
        order: 'id ASC'
    }).then(function (items) {
        if(items && items.length === 5) {
            return parseInt(1250*price*items[0].rate*items[1].rate*items[2].rate*items[3].rate*items[4].rate);
        }
        throw new Error('部分参数在表中不存在！')
    }).catch(function (error) {
        logger.error('assess error:' + error.stack);
        return -1;
    })
}

module.exports = router;
