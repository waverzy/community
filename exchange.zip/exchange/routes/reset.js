/**
 * Created by waver on 2018/1/22.
 */
var models =  require('../models');
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();

router.get('/', function(req, res, next) {
    if(!req.session.user) {
        return res.redirect('login');
    }
    logger.info('user:[' + req.session.user + '] open reset.html');
    res.render('reset');
});

router.post('/', function (req, res) {
    if(!req.session.user) {
        return res.send({'msg': 'logout'});
    }
    logger.info('user:[' + req.ip + '] begin to reset password');
    var password = req.body.password || '',
        password1 = req.body.password1 || '',
        password2 = req.body.password2 || '';
    if(password === '' || password1 === '' || password2 === '' || password1 !== password2) {
        return res.send({'msg': '传入的密码有误，请刷新页面后重试！'});
    }
    models.User.findOne({
        where: {
            name: name,
            password: password
        }
    }).then(function (user) {
        if(!user) {
            logger.info('user:[' + req.session.user + '] 旧密码验证未通过！');
            throw new Error('END');
        } else {
            user.password = password1;
            return user.save();
        }
    }).then(function () {
        logger.info('user:[' + req.session.user + '] has reset password');
        return res.send({'msg': 'success'});
    }).catch(function (error) {
        if(error.message === 'END') {
            return res.send({'msg': '当前密码错误！'});
        }
        logger.error('user:[' + req.ip + '] ' + error.stack);
        return res.send({'msg': '错误:' + error.message});
    })
});

module.exports = router;
