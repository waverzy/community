/**
 * Created by waver on 2018/1/22.
 */
var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();
var svgCaptcha = require('svg-captcha');
var models =  require('../models');

var Promise = require('bluebird');
var path = require("path");
var env = process.env.NODE_ENV || "development";
var config = require(path.join(__dirname, '..', 'config', 'config.json'))[env];
var YunpianSms = Promise.promisifyAll(require('../core/yunpianSms')).YunpianSms;
var sms = new YunpianSms();

router.get('/numPic', function (req, res) {
    logger.info('user:[' + req.ip + '] get numPic');
    var captcha = svgCaptcha.create({
        // 翻转颜色
        inverse: false,
        // 字体大小
        fontSize: 36,
        // 噪声线条数
        noise: 3,
        // 宽度
        width: 120,
        // 高度
        height: 30
    });
    req.session.captcha = captcha.text.toLowerCase();
    res.send(captcha.data);
});

router.post('/getMsg', function (req, res) {
    var mobile = req.body.mobile || '',
        picNum = req.body.picNum || '';
    if(mobile === '' || picNum === '') {
        return res.send({'msg': '手机号或图形验证码不正确！'});
    }
    if(picNum.toLowerCase() !== req.session.captcha) {
        return res.send({'msg': '图片验证码错误，请重新输入！'});
    }
    req.session.captcha = null;
    logger.info('user:[' + req.ip + ']mobile:[' + mobile + '] get ready to get message code');
    req.session.mobile = mobile;
    var num = Math.ceil(Math.random()*8999 + 1000);
    req.session.msgcode = num.toString();
    var smsData = {};
    smsData.mobile = mobile.toString();
    smsData.code = num.toString();
    sms.sendValidateMsg(smsData, function(error, response) {
        if(!error) {
            var result = JSON.parse(response.body);
            if(result.code == 0) {
                logger.info('mobile:[' + mobile + '] msgcode:[' + num + ']');
                return res.send({'msg': 'success'});
            } else {
                logger.error('user:[' + req.ip + '] mobile:[' + mobile + '] send fail:' + result.msg);
                return res.send({'msg': result.msg});
            }
        }
        else {
            logger.error('user:[' + req.ip + '] ' + error.stack);
            return res.send({'msg': error.message});
        }
    });
});

module.exports = router;
