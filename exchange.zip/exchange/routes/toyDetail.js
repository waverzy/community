var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();
var models = require('../models');
// var Promise = require('bluebird');
// var request = Promise.promisifyAll(require('request'));
// var wxUtils = Promise.promisifyAll(require('../core/wxUtils'));

router.get('/', function (req, res) {
    var tid = parseInt(req.query.id) || 0;
    if(tid === 0) {
        return res.render('error');
    }
    /*if (!req.session.openid) {
        return res.render(error);
    }
    logger.info('openid:[' + req.session.openid + '] open toys.html');*/
    var detail = {};
    models.Toydetail.findOne({
        where: {
            tid: tid
        }
    }).then(function (toydetail) {
        logger.info('user:[' + req.ip + '] query toydetail finished ');
        detail = toydetail;
        return models.Toyimage.findAll({
            where: {
                tid: tid
            }
        });
    }).then(function (toyimages) {
        var slideImgs = [];
        var mainImgs = [];
        for(var i=0; i<toyimages.length; i++) {
            if(toyimages[i].type === "slide") {
                slideImgs.push(toyimages[i].url);
            }
            if(toyimages[i].type === "main") {
                mainImgs.push(toyimages[i].url);
            }
        }
        return res.render('toyDetail', {'slideImgs': slideImgs, 'mainImgs': mainImgs, 'detail': detail});
    }).catch(function (error) {
        // logger.error('openid:[' + req.session.openid + '] ' + error.stack);
        return res.render('error');
    });
});

module.exports = router;
