var express = require('express');
var router = express.Router();
var log4js = require('../core/log4jsUtil.js'),
    logger = log4js.getLogger();
var models = require('../models');
// var Promise = require('bluebird');
// var request = Promise.promisifyAll(require('request'));
// var wxUtils = Promise.promisifyAll(require('../core/wxUtils'));

router.get('/', function (req, res) {
    /*if (!req.session.openid) {
        return res.render(error);
    }
    logger.info('openid:[' + req.session.openid + '] open toys.html');*/
    models.Toy.findAll({
        where: {
            state: true
        },
        order: 'price DESC'
    }).then(function (toys) {
        if (toys && toys.length > 0) {
            logger.info('user:[' + req.ip + '] query toys finished ');
            return res.render('toys', {'toys': toys, 'tip': false});
        } else {
            return res.render('toys', {'toys': toys, 'tip': true})
        }
    }).catch(function (error) {
        // logger.error('openid:[' + req.session.openid + '] ' + error.stack);
        return res.render('error');
    });
});

/*router.post('/addCart', function (req, res) {
    if(!req.session.user) {
        return res.send({'msg': 'logout'});
    }
    var tid = parseInt(req.body.tid) || 0;
    if(tid === 0) {
        return res.send({'msg': '页面异常，请刷新后再试！'})
    }
    models.Shopcart.findOne({
        where: {
            user: req.session.user,
            tid: tid
        }
    }).then(function (cartItem) {
        if(cartItem) {
            if(cartItem.num > 2) {
                throw new Error('单个玩具最多只能置换3个！')
            }
            return cartItem.increment('num', {by: 1});
        } else {
            return models.Shopcart.build({
                user: req.session.user,
                tid: tid}).save();
        }
    }).then(function () {
        return res.send({'msg': "success"});
    }).catch(function (error) {
        // logger.error('openid:[' + req.session.openid + '] ' + error.stack);
        logger.error(error.stack);
        return res.send({'msg': error.message});
    });
});*/

module.exports = router;
