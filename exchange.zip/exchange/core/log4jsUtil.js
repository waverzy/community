'use strict';

var log4js = require('log4js');
log4js.configure('config/log4js.config.json');

module.exports = log4js;