/**
 * Created by waver on 2018/1/22.
 */
var request = require('request');

var path = require("path");
var env = process.env.NODE_ENV || "development";
var gConfig = require(path.join(__dirname, '..', 'config', 'config.json'))[env];

function YunpianSms() {
    this.apikey = gConfig.apikey;
    this.validateMsg1 = "【执尔科技】您的本次验证码：";
    this.validateMsg2 = "，10分钟内输入有效。";
}

YunpianSms.prototype.sendValidateMsg = function (data, callback) {
    var param = {
        'apikey': this.apikey,
        'mobile': data.mobile,
        'text': this.validateMsg1 + data.code + this.validateMsg2
    };
    var api_url = 'https://sms.yunpian.com/v2/sms/single_send.json';
    request.post({
        url: api_url,
        form: param
    }, function (err, response, data) {
        if (callback) {
            callback(err, response, data);
        }
    });
};

exports.YunpianSms = YunpianSms;