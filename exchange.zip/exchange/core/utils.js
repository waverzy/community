/**
 * Created by waver on 2018/2/6.
 */
var path = require("path");
var env = process.env.NODE_ENV || "development";
var gConfig = require(path.join(__dirname, '..', 'config', 'config.json'))[env];

var utils = {};

utils.getAppid = function () {
    return gConfig.appid;
};

utils.getSecret = function () {
    return gConfig.secret;
};

utils.getToken = function () {
    return gConfig.token;
};

utils.getMchid = function () {
    return gConfig.mch_id;
};

utils.getKey = function () {
    return gConfig.key;
};

module.exports = utils;