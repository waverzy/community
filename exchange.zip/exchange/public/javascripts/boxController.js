/**
 * Created by waver on 2018/1/10.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
        refreshOldValue();
        refreshNewValue();
    }

    function initWidget() {
        loadCart();//先渲染后绑定
        $('#btn-addOld').on('click', function () {
            window.location.href = '/uploadToy';
        });
        $('input[type="checkbox"][name="old-checkbox"]').on('change', function () {
            refreshOldValue();
        });
        $('input[type="checkbox"][name="new-checkbox"]').on('change', function () {
            refreshNewValue();
        });
        $('#tab-old li').on('taphold', function () {
            var li = $(this);
            main.f7.confirm('删除后无法恢复，须重新上传', '确定删除？',
                function () {
                    removeOld(li);
                }
            );
        });
        $('#btn-removeNew').on('click', function () {
            var checkList = $('input[type="checkbox"][name="new-checkbox"]:checked');
            if (!checkList || checkList.length <= 0) {
                return main.f7.alert('请先选择需要移除的新玩具', '提示');
            }
            main.f7.confirm('确定删除？', '提示',
                function () {
                    var cartToys = getCartToys();
                    var updatedCart = [];
                    for(var i=0; i<cartToys.length; i++) {
                        var exist = false;
                        for(var j=0; j<checkList.length; j++) {
                            if(cartToys[i].tid == checkList[j].value) {
                                exist = true;
                                $('#li'+cartToys[i].tid).remove();
                                break;
                            }

                        }
                        if(!exist) {
                            updatedCart.push(cartToys[i]);
                        }
                    }
                    var storage = window.localStorage;
                    storage.setItem('cart', JSON.stringify(updatedCart));
                    setCookie('cart', JSON.stringify(updatedCart));
                }
            );
        });
        $('.btn-word').on('click', function () {

        });
    }

    function getCartToys() {
        var storage = window.localStorage;
        var cartToys = storage.getItem('cart') || getCookie('cart');
        if(cartToys) {
            return JSON.parse(cartToys);
        }
        return [];
    }

    function loadCart() {
        var cartToys = getCartToys();
        var htmlStr = "";
        cartToys.forEach(function (cartToy) {
            htmlStr += '<li id="li' + cartToy.tid + '"><label class="label-checkbox item-content">' +
                '<input type="checkbox" name="new-checkbox" checked value="' + cartToy.tid + '">' +
                '<div class="item-media"><i class="icon icon-form-checkbox"></i></div>' +
                '<div class="item-media"><img src="' + cartToy.pic + '" width="60"></div>' +
                '<div class="item-inner"><div class="item-title-row" style="margin-top: 10px;">' +
                '<div class="item-title">' + cartToy.name + '</div></div><div class="item-subtitle"></div>' +
                '<div class="item-text" style="margin-top: 10px;">' + cartToy.price + '置换豆 x ' + cartToy.num + '</div></div></li>';
        });
        if(htmlStr !== "") {
            $('#new-toys').html('<div class="list-block media-list"><ul>'+htmlStr+'</ul></div><div id="btn-removeNew" class="button button-big color-red">移 除</div>');
        }


    }

    function getToyPrice(tid) {
        var cartToys = getCartToys();
        var price = 0;
        for(var i=0; i<cartToys.length; i++) {
            if(cartToys[i].tid === parseInt(tid)) {
                price = parseInt(cartToys[i].price) * parseInt(cartToys[i].num);
                break;
            }
        }
        return price;
    }

    function refreshOldValue() {
        var checkList = $('input[type="checkbox"][name="old-checkbox"]:checked');
        if (!checkList || checkList.length <= 0) {
            return $('#old-total').text('旧玩具合计：0置换豆');
        }
        var oldTotal = 0;
        checkList.each(function () {
            oldTotal += $(this).data('price');
        });
        $('#old-total').text('旧玩具合计：' + oldTotal + '置换豆');
    }

    function refreshNewValue() {
        var checkList = $('input[type="checkbox"][name="new-checkbox"]:checked');
        if (!checkList || checkList.length <= 0) {
            return $('#new-total').text('新玩具合计：0置换豆');
        }
        var newTotal = 0;
        checkList.each(function () {
            newTotal += getToyPrice($(this).val());
        });
        $('#new-total').text('新玩具合计：' + newTotal + '置换豆');
    }

    function removeOld(li) {
        main.jquery.ajax({
            type: 'post',
            url: '/box/removeOld',
            cache: false,
            data: {
                toyid: li.data('oid')
            },
            success: function (output) {
                if (output.msg == 'success') {
                    li.remove();
                } else {
                    main.f7.alert('output.msg', '提示');
                }
            }
        });
    }

    function setCookie(key, value) {
        var expireDate=new Date();
        expireDate.setDate(expireDate.getDate()+30);
        document.cookie = key + "=" + encodeURI(value) + ";expires=" + expireDate.toUTCString();
    }

    function getCookie(key) {
        var idx = document.cookie.indexOf(key + "=");
        if(idx === -1) return "";
        var start = idx + key.length + 1,
            end = document.cookie.indexOf(";", idx);
        if(end === -1) end = document.cookie.length;
        return decodeURI(document.cookie.substr(start,end));
    }

    return {
        init: init
    }
});