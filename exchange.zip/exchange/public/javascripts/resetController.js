/**
 * Created by waver on 2018/1/19.
 */
define(['main'], function(main) {
    function init() {
        initWidget();
    }

    function initWidget() {
        $('#btn-submit').on('click', function () {
            var password = $('#old-pwd').val() || '',
                password1 = $('#new-pwd1').val() || '',
                password2 = $('#new-pwd2').val() || '';
            if(password === '') {
                $('.popover p').html('请输入旧密码！');
                main.f7.popover('.popover-tip', '#old-pwd');
                return;
            }
            if(password1 === '')  {
                $('.popover p').html('请输入新密码！');
                main.f7.popover('.popover-tip', '#new-pwd1');
                return;
            }
            if(password2 === '')  {
                $('.popover p').html('请确认新密码！');
                main.f7.popover('.popover-tip', '#new-pwd2');
                return;
            }
            if(password2 !== password1)  {
                $('.popover p').html('两次输入的新密码不一致！');
                main.f7.popover('.popover-tip', '#new-pwd2');
                return;
            }
            main.jquery.ajax({
                type: 'post',
                url: '/reset',
                cache: false,
                data: {
                    password: $.md5(password),
                    password1: $.md5(password1),
                    password2: $.md5(password2)
                },
                success: function (output) {
                    if (output.msg == 'success') {
                        if(document.referrer) {
                            window.location.href = document.referrer;
                        } else {
                            window.location.href = '/mine';
                        }
                    } else if (output.msg == 'logout') {
                        window.location.href = '/login';
                    } else {
                        main.f7.alert(output.msg, "提示");
                    }
                }
            });
        });
    }

    return {
        init: init
    }
});