/**
 * Created by waver on 2018/3/1.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
    }

    var addNew = false;

    function initWidget() {
        $('#btn-addSlide').on('click', function () {
            var timestamp = new Date().getTime().toString();
            var htmlStr = '<li class="swipeout"><div class="swipeout-content item-content">'
                + '<div class="item-inner"><div class="item-title label">轮播图</div>'
                + '<div class="item-input"><input class="ipt-slide" type="text"></div></div></div>'
                + '<div class="swipeout-actions-right"><a id="' + timestamp + '">删除</a></div></li>';
            $('.popup ul').append(htmlStr);
            $('#'+timestamp).on('click', function () {
                var slide = $(this);
                main.f7.confirm('提示', '确定删除？',
                    function () {
                        slide.parents('li').remove();
                    }
                );
            });
        });
        $('#btn-addMain').on('click', function () {
            var timestamp = new Date().getTime().toString();
            var htmlStr = '<li class="swipeout"><div class="swipeout-content item-content">'
                + '<div class="item-inner"><div class="item-title label">主图</div>'
                + '<div class="item-input"><input class="ipt-main" type="text"></div></div></div>'
                + '<div class="swipeout-actions-right"><a id="' + timestamp + '">删除</a></div></li>';
            $('.popup ul').append(htmlStr);
            $('#'+timestamp).on('click', function () {
                var slide = $(this);
                main.f7.confirm('提示', '确定删除？',
                    function () {
                        slide.parents('li').remove();
                    }
                );
            });
        });
        $('#btn-edit').on('click', function () {
            addNew = false;
            var checkList = $('input[type="checkbox"][name="toys-checkbox"]:checked');
            if (!checkList || checkList.length !== 1) {
                return main.f7.alert('请选择一条需要编辑的内容', '提示');
            }
            main.jquery.ajax({
                type: 'post',
                url: '/adminToys/get',
                cache: false,
                data: {
                    id: checkList[0].value
                },
                success: function (output) {
                    if (output.msg == 'success') {
                        $('#ipt-shortName').val(output.toy.shortName);
                        $('#ipt-pic').val(output.toy.pic);
                        $('#ipt-desc').val(output.toy.desc);
                        $('#ipt-price').val(output.toy.price);
                        $('#sel-state').val(output.toy.state==true ? '1' : '0');
                        $('#ipt-name').val(output.toy.name);
                        $('#ipt-age').val(output.toy.age);
                        $('#ipt-battery').val(output.toy.battery);
                        $('#ipt-description').val(output.toy.description);
                        $('#ipt-info').val(output.toy.info);
                        $('#ipt-tip').val(output.toy.tip);
                        var slideImages = output.toy.slide,
                            mainImages = output.toy.main;
                        $('.swipeout').remove();
                        slideImages.forEach(function (val) {
                            var htmlStr = '<li class="swipeout"><div class="swipeout-content item-content">'
                                        + '<div class="item-inner"><div class="item-title label">轮播图</div>'
                                        + '<div class="item-input"><input class="ipt-slide" type="text" value="' + val + '" ></div></div></div>'
                                        + '<div class="swipeout-actions-right"><a class="btn-slide">删除</a></div></li>';
                            $('.popup ul').append(htmlStr);
                        });
                        mainImages.forEach(function (val) {
                            var htmlStr = '<li class="swipeout"><div class="swipeout-content item-content">'
                                + '<div class="item-inner"><div class="item-title label">主图</div>'
                                + '<div class="item-input"><input class="ipt-main" type="text" value="' + val + '"></div></div></div>'
                                + '<div class="swipeout-actions-right"><a class="btn-slide">删除</a></div></li>';
                            $('.popup ul').append(htmlStr);
                        });
                        $('.btn-slide').on('click', function () {
                            var slide = $(this);
                            main.f7.confirm('提示', '确定删除？',
                                function () {
                                    slide.parents('li').remove();
                                }
                            );
                        });
                        main.f7.popup('.popup');
                    } else if(output.msg == 'logout') {
                        window.location.href = '/adminLogin';
                    } else {
                        main.f7.alert(output.msg, '提示');
                    }
                }
            });
        });
        $('#btn-delete').on('click', function () {
            var checkList = $('input[type="checkbox"][name="toys-checkbox"]:checked');
            if (!checkList || checkList.length < 1) {
                return main.f7.alert('请选择需要删除的记录', '提示');
            }
            main.f7.confirm('确定下架？', '提示',
                function () {
                    var toys = [];
                    checkList.each(function () {
                        toys.push($(this).val());
                    });
                    main.jquery.ajax({
                        type: 'post',
                        url: '/adminToys/delete',
                        cache: false,
                        data: {
                            toys: JSON.stringify(toys)
                        },
                        success: function (output) {
                            if (output.msg == 'success') {
                                main.f7.alert('已完成下架', '提示');
                            } else if(output.msg == 'logout') {
                                window.location.href = '/adminLogin';
                            } else {
                                main.f7.alert(output.msg, '提示');
                            }
                        }
                    });
                }
            );
        });
        $('#btn-view').on('click', function () {
            var checkList = $('input[type="checkbox"][name="toys-checkbox"]:checked');
            if (!checkList || checkList.length !== 1) {
                return main.f7.alert('请选择一条需要预览的内容', '提示');
            }
            window.location.href = '/toyDetail?id=' + checkList[0].value;
        });
        $('#btn-submit').on('click', function () {
            var params = {};
            var reqUrl = '/adminToys/add';
            if(!addNew) {
                var checkList = $('input[type="checkbox"][name="toys-checkbox"]:checked');
                if (!checkList || checkList.length !== 1) {
                    return main.f7.alert('请选择一条需要编辑的内容', '提示');
                }
                params.tid = checkList[0].value;
                reqUrl = '/adminToys/edit';
            }
            params.shortName = $('#ipt-shortName').val() || '';
            params.pic = $('#ipt-pic').val() || '';
            params.desc = $('#ipt-desc').val() || '';
            params.price = $('#ipt-price').val() || '';
            params.state = $('#sel-state').val();
            params.name = $('#ipt-name').val() || '';
            params.age = $('#ipt-age').val() || '';
            params.battery = $('#ipt-battery').val() || '';
            params.description = $('#ipt-description').val() || '';
            params.info = $('#ipt-info').val() || '';
            params.tip = $('#ipt-tip').val() || '';
            if(params.shortName === '' || params.pic === '' || params.desc === '' || params.price === '' || params.state === '' || params.name === '' || params.age === '' || params.battery === '' || params.description === '' || params.info === '' || params.tip === '') {
                return main.f7.alert('存在输入框内容为空！', '提示')
            }
            params.slideImages = [];
            params.mainImages = [];
            $('.ipt-slide').each(function () {
                if($(this).val() && $(this).val().length > 0) {
                    params.slideImages.push($(this).val());
                }
            });
            $('.ipt-main').each(function () {
                if($(this).val() && $(this).val().length > 0) {
                    params.mainImages.push($(this).val());
                }
            });
            main.jquery.ajax({
                type: 'post',
                url: reqUrl,
                cache: false,
                data: {
                    params: JSON.stringify(params)
                },
                success: function (output) {
                    if (output.msg == 'success') {
                        window.location.href = '/adminToys';
                    } else if (output.msg == 'logout') {
                        window.location.href = '/adminLogin';
                    } else {
                        main.f7.alert(output.msg, '提示');
                    }
                }
            });
        });
        $('#btn-add').on('click', function () {
            addNew = true;
            main.f7.popup('.popup');
        });
    }

    return {
        init: init
    }
});