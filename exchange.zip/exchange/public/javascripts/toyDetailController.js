/**
 * Created by waver on 2018/1/9.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
    }

    function initWidget() {
        $('.icon-back').on('click', function () {
            if(document.referrer && document.referrer.indexOf('toys')<0) {
                window.location.href = document.referrer;
            } else {
                window.location.href = '/toys#toy' + getTid();
            }
        });
    }

    function getTid() {
        var url = location.search;
        if (url.indexOf("?") != -1) {
            var str = url.substr(1),
            params = str.split("=");
            var tid = params[1] || '0';
            return tid;
        }
    }

    return {
        init: init
    }
});