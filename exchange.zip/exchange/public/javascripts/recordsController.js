/**
 * Created by waver on 2018/1/19.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
    }

    function initWidget() {
        $('.col-33 img').on('click', function () {
            window.location.href = '/toyDetail?id=' + $(this).data('tid');
        });
    }

    return {
        init: init
    }
});