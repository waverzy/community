/**
 * Created by waver on 2018/1/19.
 */
define(['main'], function(main) {
    function init() {
        initWidget();
    }

    function initWidget() {
        $('#btn-login').on('click', function () {
            var name = $('#username').val() || '',
                password = $('#password').val() || '';
            if(name === '' || password === '')  {
                $('.popover p').html('请输入用户名和密码');
                main.f7.popover('.popover-tip', '#password');
                return;
            }
            var password = $.md5($('#password').val());
            main.jquery.ajax({
                type: 'post',
                url: '/login',
                cache: false,
                data: {
                    name: name,
                    password: password
                },
                success: function (output) {
                    if (output.msg == 'success') {
                        if(document.referrer) {
                            window.location.href = document.referrer;
                        } else {
                            window.location.href = '/index';
                        }
                    } else {
                        $('.popover p').html(output.msg);
                        main.f7.popover('.popover-tip', '#password');
                    }
                }
            });
        });
    }

    return {
        init: init
    }
});