/**
 * Created by waver on 2018/1/22.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
        wxConfig();
    }

    function wxConfig() {
        main.jquery.ajax({
            type: 'post',
            url: '/wechat/jsapi',
            cache: false,
            data: {
                url: encodeURIComponent(location.href.split('#')[0])
            },
            success: function (output) {
                if (output.msg === 'success') {
                    wx.config({
                        debug: false,
                        appId: output.appId,
                        timestamp: output.timestamp,
                        nonceStr: output.nonceStr,
                        signature: output.signature,
                        jsApiList: ["onMenuShareTimeline"]
                    });
                } else {
                    main.f7.alert(output.msg, '提示');
                }
            }
        });
    }

    function initWidget() {
        $('#btn-record').on('click', function () {
            window.location.href = '/records';
        });
        $('#btn-set').on('click', function () {
            window.location.href = '/reset';
        });
        $('#btn-share').on('click', function () {
            wx.onMenuShareTimeline({
                title: '置换新品，让角落里的旧玩具“活”起来',
                link: 'http://wx.zhiertech.com/index',
                imgUrl: 'images/history.jpg', // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                }
            });

        });
        $('#btn-about').on('click', function () {
            window.location.href = '/about';
        });
    }

    return {
        init: init
    }
});