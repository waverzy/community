/**
 * Created by waver on 2018/1/8.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
        refreshCart();
    }

    function initWidget() {
        $('.a-detail').on('click', function () {
            window.location.href = '/toyDetail?id=' + $(this).data('id');
        });
        $('.btn-add').on('click', function () {
            var tid = $(this).data('id');
            var toy = {};
            toy.tid = tid;
            toy.pic = $('#toy'+tid+' img').attr('src');
            toy.name = $('#toy'+tid+' .toy-name').text();
            var priceStr = $('#toy' + tid + ' .toy-price').text();
            toy.price = priceStr.substr(0, priceStr.length-3);
            toy.updatedAt = $('#toy'+tid+' .toy-time').text();
            toy.num = 1;

            var storage = window.localStorage;
            var cartToys = storage.getItem('cart') || getCookie('cart');
            if(cartToys) {
                cartToys = JSON.parse(cartToys);
                for(var i=0; i<cartToys.length; i++) {
                    if(cartToys[i].tid == tid) {
                        if(cartToys[i].num >= 5) {
                            $('#cart-fail').fadeIn();
                            setTimeout(function () {
                                $('#cart-fail').fadeOut();
                            }, 200);
                            return;
                        }
                        cartToys[i].num++;
                        storage.setItem('cart', JSON.stringify(cartToys));
                        setCookie('cart', JSON.stringify(cartToys));
                        $('#cart-success').fadeIn();
                        setTimeout(function () {
                            $('#cart-success').fadeOut();
                        }, 200);
                        return;
                    }
                }
            } else {
                cartToys = [];
            }
            cartToys.push(toy);
            storage.setItem('cart', JSON.stringify(cartToys));
            setCookie('cart', JSON.stringify(cartToys));
            $('#cart-success').fadeIn();
            setTimeout(function () {
                $('#cart-success').fadeOut();
            }, 800);
        });
    }

    function refreshCart() {
        var storage = window.localStorage;
        var cartToys = storage.getItem('cart') || getCookie('cart');
        if(cartToys) {
            cartToys = JSON.parse(cartToys);
            cartToys.forEach(function (cartToy) {
                var freshTime = new Date($('#toy'+cartToy.tid+' .toy-time').text());
                var localTime = new Date(cartToy.updatedAt);
                if(freshTime > localTime) {
                    cartToy.pic = $('#toy'+cartToy.tid+' img').attr('src');
                    cartToy.name = $('#toy'+cartToy.tid+' .toy-name').text();
                    var priceStr = $('#toy'+cartToy.tid+' .toy-price').text();
                    cartToy.price = priceStr.substr(0, priceStr.length-3);
                    cartToy.updatedAt = $('#toy'+cartToy.tid+' .toy-time').text();
                    cartToy.num = 1;
                }
            });
            storage.setItem('cart', JSON.stringify(cartToys));
            setCookie('cart', JSON.stringify(cartToys));
        }
    }

    function setCookie(key, value) {
        var expireDate=new Date();
        expireDate.setDate(expireDate.getDate()+30);
        document.cookie = key + "=" + encodeURI(value) + ";expires=" + expireDate.toUTCString();
    }

    function getCookie(key) {
        var idx = document.cookie.indexOf(key + "=");
        if(idx === -1) return "";
        var start = idx + key.length + 1,
            end = document.cookie.indexOf(";", idx);
        if(end === -1) end = document.cookie.length;
        return decodeURI(document.cookie.substr(start,end));
    }

    return {
        init: init
    }
});