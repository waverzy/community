/**
 * Created by waver on 2018/1/22.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
    }

    function initWidget() {
        $('#btn-questions').on('click', function () {
            window.location.href = '/questions';
        });
    }

    return {
        init: init
    }
});