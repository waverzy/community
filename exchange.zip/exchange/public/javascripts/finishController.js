/**
 * Created by waver on 2018/2/14.
 */
define(['main'], function (main) {
    function init() {
        initWidget();
    }

    function initWidget() {
        $('#btn-index').on('click', function () {
            window.location.href = '/records';
        });
    }

    return {
        init: init
    }
});