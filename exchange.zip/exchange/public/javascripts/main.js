/**
 * Created by waver on 2018/1/4.
 */
require.config({
    paths: {
        jquery: './lib/jquery.min',
        jweixin: './lib/jweixin-1.2.0',
        md5: 'lib/jquery.md5',
        fastclick: 'lib/fastclick'
    },
    shim : {
        md5: {
            deps: ['jquery']
        }
    }
});

define('main', ['jquery', 'md5', 'fastclick', 'jweixin'], function(JQuery, md5, FastClick, wx) {
    var $ = Dom7;
    var controllerName = '';
    $(document).on('pageBeforeInit', function(e) {
        controllerName = $('.page').attr('data-page');
        if(controllerName !== 'address' && e.detail.page.from === 'center') {
            require([controllerName + 'Controller'], function(controller){
                controller.init();
            });
        }
        // FastClick.attach(document.body);
    });

    var f7 = new Framework7({
        modalButtonOk: "确定",
        modalButtonCancel: "取消",
        tapHold: true
    });
    var mainView = f7.addView('.view-main');
    if(controllerName === 'box') {
        mainView.params.domCache = true;
    }
    var mySwiper = f7.swiper('.swiper-container', {
        pagination:'.swiper-pagination',
        speed: 200,
        spaceBetween: 20
    });
    return {
        f7: f7,
        mainView: mainView,
        jquery: JQuery,
        wx: wx
    };
});
