/**
 * Created by waver on 2018/1/19.
 */
define(['main'], function(main) {
    function init() {
        initWidget();
    }

    function initWidget() {
        refreshNumPic();

        $('#img-numPic').on('click', function () {
            refreshNumPic();
        });

        $('#btn-msg').on('click', function () {
            if(!checkMobile()) {
                return main.f7.alert("请输入合法手机号！", "提示");
            }
            if($('#ipt-code').val() === "") {
                return main.f7.alert("请输入图片验证码", "提示");
            }
            // 计时器
            var seconds = 60;
            // 处理获取验证码时发生的动作
            var handleCount = function() {
                $('#btn-msg').attr("disabled", true);
                $('#btn-msg').text(seconds-- + "秒后重发");
                $('#btn-msg').css({
                    "background" : "#CCCCCC"
                });
            };
            handleCount();
            var startCountDown = window.setInterval(function() {
                handleCount();
            }, 1000);
            // 60 秒之后清除计时器
            var clearCountDown = setTimeout(function () {
                $('#btn-msg').text("获取短信验证码");
                $('#btn-msg').attr("style", {
                    "background": "none"
                });
                $('#btn-msg').attr("disabled", false);
                window.clearInterval(startCountDown);
            }, 60000);

            main.jquery.ajax({
                type: 'post',
                url: '/public/getMsg',
                cache: false,
                data: {
                    picNum: $('#ipt-code').val(),
                    mobile: $('#ipt-mobile').val()
                },
                success: function (output) {
                    if (output.msg !== 'success') {
                        refreshNumPic();
                        $('#btn-msg').text("获取短信验证码");
                        $('#btn-msg').attr("style", {
                            "background": "none"
                        });
                        $('#btn-msg').attr("disabled", false);
                        clearInterval(startCountDown); // 清除定时器
                        clearTimeout(clearCountDown);
                        return main.f7.alert(output.msg, "提示");
                    }
                },
                error: function () {
                    refreshNumPic();
                    $('#btn-msg').text("获取短信验证码");
                    $('#btn-msg').attr("style", {
                        "background": "none"
                    });
                    $('#btn-msg').attr("disabled", false);
                    clearInterval(startCountDown); // 清除定时器
                    clearTimeout(clearCountDown);
                    main.f7.alert("网络异常，请稍后再试！", "提示");
                }
            });
        });

        $('#btn-submit').on('click', function () {
            if(!checkMobile()) {
                return main.f7.alert("请输入合法手机号！", "提示");
            }
            if($('#ipt-msg').val() === "") {
                return main.f7.alert("请输入短信验证码", "提示");
            }
            if($('#ipt-pwd').val() === "") {
                return main.f7.alert("请设置登录密码", "提示");
            }
            main.jquery.ajax({
                type: 'post',
                url: '/register',
                cache: false,
                data: {
                    msgcode: $('#ipt-msg').val(),
                    mobile: $('#ipt-mobile').val(),
                    password: $.md5($('#ipt-pwd').val())
                },
                success: function (output) {
                    if (output.msg === 'success') {
                        main.f7.modal({
                            title:  '恭喜',
                            text: '注册成功！'
                        });
                        setTimeout(function(){
                            main.f7.closeModal();
                            window.location.href = '/login';
                        },2000);
                    } else {
                        main.f7.alert(output.msg, "提示");
                    }
                },
                error: function () {
                    main.f7.alert("网络异常，请稍后再试！", "提示");
                }
            });
        });
    }

    function checkMobile() {
        return /^1(3|4|5|7|8)[0-9]\d{8}$/.test($('#ipt-mobile').val());
    }

    function refreshNumPic() {
        main.jquery.ajax({
            type: 'get',
            url: '/public/numPic',
            cache: false,
            success: function (data) {
                $('#img-numPic').html(data);
            }
        });
    }

    return {
        init: init
    }
});