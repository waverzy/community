/**
 * Shopping cart
 * Created by waver on 2018/1/9.
 */

module.exports = function(sequelize, DataTypes) {
    var Shopcart = sequelize.define("Shopcart", {
        sid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        user: {type: DataTypes.STRING, unique: 'compositeIndex'},
        tid: {type: DataTypes.INTEGER, unique: 'compositeIndex'},
        num: {type: DataTypes.INTEGER, defaultValue: 1}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Shopcart.sync().then(function() {
    //
    }).catch(function(error) {
        console.log(error);
    });

    return Shopcart;
};