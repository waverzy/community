/**
 * Created by waver on 2018/1/9.
 */

module.exports = function(sequelize, DataTypes) {
    var User = sequelize.define("User", {
        uid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        name: {type: DataTypes.STRING, allowNull: false, unique: true},
        password: {type: DataTypes.STRING, allowNull: false}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    User.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return User;
};