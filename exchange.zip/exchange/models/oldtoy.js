/**
 * OldToy
 * Created by waver on 2018/1/17.
 */

module.exports = function(sequelize, DataTypes) {
    var Oldtoy = sequelize.define("Oldtoy", {
        oid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        user: DataTypes.STRING,
        name: DataTypes.STRING,
        marketprice: DataTypes.INTEGER,
        assessprice: DataTypes.INTEGER,
        price: DataTypes.INTEGER,
        brand: DataTypes.STRING,
        category: DataTypes.STRING,
        old: DataTypes.STRING,
        damage: DataTypes.STRING,
        func: DataTypes.STRING,
        pic: DataTypes.STRING,
        state: DataTypes.STRING, //reviewing,accepted,rejected,used,removed
        comment: DataTypes.STRING},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Oldtoy.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Oldtoy;
};