/**
 * PayResult
 * Created by waver on 2018/2/28.
 */

module.exports = function(sequelize, DataTypes) {
    var Payresult = sequelize.define("Payresult", {
        pid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        appid: DataTypes.STRING,
        mch_id: DataTypes.STRING,
        nonce_str: DataTypes.STRING,
        sign: DataTypes.STRING,
        result_code: DataTypes.STRING,
        openid: DataTypes.STRING,
        trade_type: DataTypes.STRING,
        bank_type: DataTypes.STRING,
        total_fee: DataTypes.INTEGER,
        cash_fee: DataTypes.INTEGER,
        transaction_id: DataTypes.STRING,
        out_trade_no: DataTypes.STRING,
        time_end: DataTypes.STRING},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Payresult.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Payresult;
};