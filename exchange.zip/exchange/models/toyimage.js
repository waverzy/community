/**
 * Toyimage
 * Created by waver on 2018/1/8.
 */

module.exports = function(sequelize, DataTypes) {
    var Toyimage = sequelize.define("Toyimage", {
        id: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        tid: {type: DataTypes.INTEGER},
        type: {type: DataTypes.STRING},
        url: {type: DataTypes.STRING(1000)}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Toyimage.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Toyimage;
};