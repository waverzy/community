/**
 * Order
 * Created by waver on 2018/1/19.
 */

module.exports = function(sequelize, DataTypes) {
    var Order = sequelize.define("Order", {
        oid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        user: DataTypes.STRING,
        oldprice: DataTypes.INTEGER,
        newprice: DataTypes.INTEGER,
        logifee: DataTypes.FLOAT,//配送费用
        address: DataTypes.STRING,
        custname: DataTypes.STRING,
        mobile: DataTypes.STRING,
        logitime: DataTypes.STRING,//配送时间
        prepayid: DataTypes.STRING,
        paytime: DataTypes.DATE,//prepay_id 2小时过期
        state: DataTypes.STRING},//finished, unpaid, paid, canceled
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Order.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Order;
};