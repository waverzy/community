/**
 * Toy
 * Created by waver on 2018/1/8.
 */

module.exports = function(sequelize, DataTypes) {
    var Toydetail = sequelize.define("Toydetail", {
        tid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        description: {type: DataTypes.STRING(2000)},
        name: {type: DataTypes.STRING},
        age: {type: DataTypes.STRING},
        battery: {type: DataTypes.STRING},
        tip: {type: DataTypes.STRING},
        info: {type: DataTypes.STRING}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Toydetail.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Toydetail;
};