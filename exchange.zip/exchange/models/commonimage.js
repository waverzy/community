/**
 * Commonimage
 * Created by waver on 2018/1/22.
 */

module.exports = function(sequelize, DataTypes) {
    var Commonimage = sequelize.define("Commonimage", {
        id: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        type: {type: DataTypes.STRING},
        url: {type: DataTypes.STRING(1000)}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Commonimage.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Commonimage;
};