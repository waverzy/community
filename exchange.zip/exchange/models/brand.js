/**
 * Brand
 * Created by waver on 2018/1/12.
 */

module.exports = function(sequelize, DataTypes) {
    var Brand = sequelize.define("Brand", {
        bid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        name: {type: DataTypes.STRING},
        rate: {type: DataTypes.DOUBLE},
        level: {type: DataTypes.STRING}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Brand.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Brand;
};