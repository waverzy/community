/**
 * Record
 * Created by waver on 2018/1/18.
 */

module.exports = function(sequelize, DataTypes) {
    var Record = sequelize.define("Record", {
        rid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        oid: DataTypes.INTEGER,
        tid: DataTypes.STRING,
        name: DataTypes.STRING,
        price: DataTypes.INTEGER,
        pic: DataTypes.STRING,
        num: DataTypes.INTEGER,
        type: DataTypes.STRING},//new, old
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Record.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Record;
};