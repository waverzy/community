/**
 * Toy
 * Created by waver on 2018/1/8.
 */

module.exports = function(sequelize, DataTypes) {
    var Toy = sequelize.define("Toy", {
        tid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        name: {type: DataTypes.STRING},
        pic: {type: DataTypes.STRING},
        description: {type: DataTypes.STRING},
        price: {type: DataTypes.INTEGER},
        state: {type: DataTypes.BOOLEAN, defaultValue: true}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Toy.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Toy;
};