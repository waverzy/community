/**
 * Deliverytime
 * Created by waver on 2018/1/31.
 */

module.exports = function(sequelize, DataTypes) {
    var Deliverytime = sequelize.define("Deliverytime", {
        id: {type: DataTypes.INTEGER, primaryKey: true},
        datestring: DataTypes.STRING,
        weekday: DataTypes.INTEGER, // 0:Sunday 1:Monday 2:Tuesday ....
        period: DataTypes.STRING, // 18:00-20:00 ...
        type: {type: DataTypes.STRING}},//time, holiday
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Deliverytime.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Deliverytime;
};