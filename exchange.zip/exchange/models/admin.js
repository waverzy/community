/**
 * Created by waver on 2018/1/23.
 */

module.exports = function(sequelize, DataTypes) {
    var Admin = sequelize.define("Admin", {
        uid: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
        name: DataTypes.STRING,
        password: DataTypes.STRING,
        auth: DataTypes.STRING},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Admin.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Admin;
};