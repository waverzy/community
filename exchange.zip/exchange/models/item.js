/**
 * Item
 * Created by waver on 2018/1/12.
 */

module.exports = function(sequelize, DataTypes) {
    var Item = sequelize.define("Item", {
        id: {type: DataTypes.INTEGER, primaryKey: true},
        name: {type: DataTypes.STRING},
        rate: {type: DataTypes.DOUBLE},
        type: {type: DataTypes.STRING}},
        {
            charset: 'utf8',
            collate: 'utf8_general_ci'
    });

    Item.sync().then(function() {
        //
    }).catch(function(error) {
        console.log(error);
    });

    return Item;
};